
//
//  ______                     _   _ _                      _____  _____ 
//  | ___ \                   | | | (_)                    |  _  ||____ |
//  | |_/ / __ _   _ ___  __ _| |_| |___   _____     __   _| |/' |    / /
//  |  __/ '__| | | / __|/ _` |  _  | \ \ / / _ \    \ \ / /  /| |    \ \ 
//  | |  | |  | |_| \__ \ (_| | | | | |\ V /  __/     \ V /\ |_/ /.___/ /     /_/_      .'''.
//  \_|  |_|   \__,_|___/\__,_\_| |_/_| \_/ \___|      \_/  \___(_)____/   =O(_)))) ...'     `.                                                                                                                                  
//                                                                            \_\    
//                                                                                   /_/_      .'''.
//                                                                                =O(_)))) ...'     `.
//                                                                                   \_\              `.    .'''
//                                                                                                      `..'
// *************************************************************************************************
// 2022 PrusaHive V0.3 by Leoš Hort and Max Klimeš developed in Prusalab facilities in Prague      https://prusalab.cz/
//
// Goal of this project is to develop a fully open source online beehive monitoring solution based on
// common parts and technologies. PrusaHive is meant to be built in DIY fashion by enthusiastic individuals,
// fablabs, makerspaces and technological institutions. The ultimate purpose of this mission is to bring
// excitement and joy of beekeeping into the makers community and beyond.
//
// Full project documentation available at wikifactory                              https://wikifactory.com/@prusalab/prusahive
// Development of this project was made possible thanks to Prusa Research s.r.o.    https://www.prusa3d.cz/
// Open Source release: http://opensource.org/licenses/GPL-3.0
// Review license in entirety and note particularly sections 15 & 16.
// Built in Platformio IDE for Visual Studio Code                                   https://platformio.org/platformio-ide
// Based largely on works of german collective behind Hiveeyes project              https://www.hiveeyes.org/
// Thanks to Matej Suchanek and Martin Spanhel for their insight and help

#include <Arduino.h>           // need to call this in order to compile in Platformio IDE
#include <HX711.h>             // ADC library for working with loadcells
#include <WiFi.h>              // wifi library
#include <HTTPClient.h>        // server communication library
#include <ezTime.h>            // library for generating ISO8601 timestamp
#include <OneWire.h>           // onewire library we use to sport multiple temperature sensors
#include <DallasTemperature.h> // library for working with a temperature sesors
#include <Wire.h>              // library for communicating with I2C devices
#include <SPI.h>               // common library for communication with SPI (Serial Peripheral Interface) devices
#include <Adafruit_Sensor.h>   // common library for SPI sensors by Adafruit
#include <Adafruit_BME280.h>
#include <InfluxDbClient.h>
#include <InfluxDbCloud.h>
#include <WiFiMulti.h>


//InfluxDB stuff
#define DEVICE "ESP32"
#define WIFI_SSID "Prusa Research Guest"                                                                                       //Network Name
#define WIFI_PASSWORD "prusaguest"                                                                                //Network Password
#define INFLUXDB_URL "https://eu-central-1-1.aws.cloud2.influxdata.com"                                                  //InfluxDB v2 server url, e.g. https://eu-central-1-1.aws.cloud2.influxdata.com (Use: InfluxDB UI -> Load Data -> Client Libraries)
#define INFLUXDB_TOKEN "XXIsUTIIhuk1EskHh2eGG9Lxxg8PAgArhM51ngqejO94eGdFB6M1HmHL9FRpDIDngH7DbLPxxUZs0ML8XICNpg=="        //InfluxDB v2 server or cloud API token (Use: InfluxDB UI -> Data -> API Tokens -> <select token>)
#define INFLUXDB_ORG "prusahive@gmail.com"                                                                                //InfluxDB v2 organization id (Use: InfluxDB UI -> User -> About -> Common Ids )
#define INFLUXDB_BUCKET "prusahive's Bucket"                                                                                 //InfluxDB v2 bucket name (Use: InfluxDB UI ->  Data -> Buckets)
#define TZ_INFO "CET-1CEST,M3.5.0,M10.5.0/3"   

// NOW THIS IS IMPORTANT, YOU CHANGE VALUES HERE DEPENDING ON YOUR NEEDS****************************
const char *ssid = "Prusa Research Guest";                       // wifi name
const char *password = "prusaguest";                             // wifi password
const char *beepKey = "prusahive1";                            // YOUR SPECIFIC DEV EUI CODE
const char *beepAdress = "https://api.beep.nl/api/sensors?key="; // BEEP.NL SERVER ADRESS
const float tempCompensationFactor = 6.0;                        // Temperature compensation for loadcell (°C per 1kg of drift)

// GENERAL VARIABLES********************************************************************************
float weightRaw = 1.1;         // variable for reading from the loadcell
float tempInside = 1.1;        // temperature variable for measurements outside of beehive
float tempOutside1 = 1.1;      // temperature variable for measurements inside of hive
float HumidityOut = 1.42;      // variable for humidity outside hive
float PressureOut = 1.34;      // variable for pressure outside hive
int battery = 3452;            // battery level variable
int NumConnect = 0;            // counter of connectons to the wifi network
float weightOffset = 1.1;      // offset variable for weightcell
String isoTime = "sampletext"; // general variable for time in the ISO6801 format

// DEFINITIONS**************************************************************************************
#define uS_TO_S_FACTOR 1000000ULL // Conversion factor for micro seconds to seconds
#define TIME_TO_SLEEP 1500        // Time ESP32 will go to sleep for (in seconds)
#define ONE_WIRE_BUS 13           // Data wire is plugged into port 17 on the board
#define PIN_VBAT 35               // pin to measure battery voltage on according to board documentation (voltage divider)
const int LOADCELL_DOUT_PIN = 35;                     //com pin
const int LOADCELL_SCK_PIN = 33;                      //clock pin
const long LOADCELL_DIVIDER = 32475.f;               //SCALE CALIBRATION, ADJUST IF NEEDED

// Setup a oneWire instance to communicate with any OneWire devices (not just Maxim/Dallas temperature ICs)
OneWire oneWire(ONE_WIRE_BUS);


// Pass our oneWire reference to Dallas Temperature.
DallasTemperature sensors(&oneWire);

// weight sensor declaration
HX711 loadcell; 

// BME280 sensor declaration
Adafruit_BME280 bme; // I2C

// INDIVIDUAL FUNCTIONS*****************************************************************************
void readBattery()
{
    battery = analogRead(PIN_VBAT); // read the divided value on pin 35
    battery = battery * 5.35;       // adjust variable back to readable format
    Serial.print("battery: ");      // print text "battery"
    Serial.println(battery);        // print the "battery variable

}

void wifiConnect()
{
    NumConnect = 0;                       // reset the wificonnection counter
    delay(4000);                          // Delay needed before calling the WiFi.begin
    WiFi.begin(ssid, password);           // accessing the wifi network
    while (WiFi.status() != WL_CONNECTED) // Check for the connection
    {
        delay(5000);                                          // wait 5sec before initializing wifi connection
        Serial.println("Connecting to WiFi..");               // print a message
        Serial.println("Attempt number" + String(NumConnect)); // print the amount of attempts to connect
        if (NumConnect++ > 5)                                 // do following if the device cannot reach the wifi in five tries
        {
            Serial.println("Cannot connect to the WiFi network");                      // print a message
            Serial.println("aborting ");                                               // print a message
            esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR);             // set deep sleep timer
            Serial.println("Lets try again in " + String(TIME_TO_SLEEP) + " Seconds"); // print a message
            Serial.println("Going to sleep now");                                      // print a message
            esp_deep_sleep_start();                                                    // put esp in deepsleep
        }
    }

    Serial.println("Connected to the WiFi network"); //print a message
}

void readWeight()
{
    loadcell.begin(LOADCELL_DOUT_PIN, LOADCELL_SCK_PIN); //inicialize scale

    //long OFFSET = loadcell.read_average();               //calculates the weight offset, COMMENT(//) AFTER ZEROING SCALE
    //Serial.println("Copy this offset variable and paste it in the next line: ");//COMMENT(//) AFTER ZEROING SCALE
    long OFFSET = 243483;                                  //UNCOMMENT AFTER ZEROING SCALE AND PASTING VALUE FROM SERIAL MONITOR
    //Serial.println(OFFSET);                              //prints the weight offset number to the serial monitor, COMMENT(//) AFTER ZEROING SCALE AND PASTE TO PREVIOUS LINE
    loadcell.set_offset(OFFSET);
    loadcell.set_scale(LOADCELL_DIVIDER);                  //calibrating scale


    if (loadcell.wait_ready_timeout(1000))          // reaching for the loadcell within one second
    {                                               // wait time for searching for AD module, if it initializes follow
        weightRaw = loadcell.get_units(10);         // calculating average from ten readings
        //weightRaw = -weightRaw;                   // converting the weight reading from negative to positive values
        //weightRaw = 194.15;                         // dummy value for testing
        Serial.print("Weight reading: ");           // print text "weight"
        Serial.println(weightRaw);                  // print the weightRaw variable
    }
    else
    {                                       // if module cannot reach the AD module do following
        Serial.println("HX711 not found."); // print a message
        weightRaw = 200.14;                 // setting up the variable for dummy number so the issue is visible on the server
    }
    loadcell.power_down(); // put the ADC in sleep mode
}

void readTemperatures()
{
    sensors.begin();           //startup the temp sensors
    sensors.setResolution(10); //set the resolution of the sensors
    bme.begin(0x76);  
    Serial.print("Requesting temperatures...");                  // print a message
    sensors.requestTemperatures();                               // Send the command to get temperatures
    Serial.println("DONE");                                      // print a message
    tempInside = bme.readTemperature();                          // read temperature with BME280
    Serial.println("tempInside");                                // print variable name
    Serial.println(tempInside);                                  // print tempinside value
    Serial.print("Temperature for the device 2 (index 1) is: "); // print a message
    tempOutside1 = sensors.getTempCByIndex(0);                   // read the specific sensor valua ByIndex
    Serial.println("tempOutside1");                              // print variable name
    Serial.println(tempOutside1);                                // print the actual value of the variable
    Serial.println("Measuring humidity...");                     // print variable name
    PressureOut = bme.readHumidity();                            // measure humidity with BME280
    Serial.println("DONE");                                      // print message
    Serial.println(HumidityOut);                                 // print humidity value
    Serial.println("Reading pressure...");                       // print variable name
    PressureOut = bme.readPressure();                            // measure pressure with BME280
    Serial.println("DONE");                                      // print message
    Serial.println(PressureOut);                                 // print pressure value
}

void readTime()
{
    waitForSync();                                       // sync for the timestamp
    isoTime = dateTime(ISO8601);                         // get time variable
    Serial.println("IS8601:      " + (isoTime));         // print the timestamp in ISO8601 format
}

void httpPost(String adress, String key, String api, float sensor)
{
    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status
        HTTPClient http;
        Serial.print("HTTPPOST to adress: ");                                              //print a message
        Serial.println(String(adress) + String(key) + "&" + String(api) + String(sensor)); //print a destination of the HTTPpost request
        http.begin(String(adress) + String(key) + "&" + String(api) + String(sensor));     //Specify destination for HTTP request
        int httpResponseCode = http.POST("whatever");                                      //Send the actual POST request
        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {
            Serial.print("Error on sending POST: "); //print a message
            Serial.println(httpResponseCode);        //print the responsecode
        }
        http.end();                                  //Free resources
    }
    else
    {
        Serial.println("Error in WiFi connection");  //print a message
    }
}

void sendinfluxDB();
{

  // Clear fields for reusing the point. Tags will remain untouched
  sensor.clearFields();

  // Store measured value into point
  // Report RSSI of currently connected network
  sensor.addField("rssi", WiFi.RSSI());

  // Print what are we exactly writing
  Serial.print("Writing: ");
  Serial.println(sensor.toLineProtocol());

  // Check WiFi connection and reconnect if needed
  if (wifiMulti.run() != WL_CONNECTED) {
    Serial.println("Wifi connection lost");
  }

  // Write point
  if (!client.writePoint(sensor)) {
    Serial.print("InfluxDB write failed: ");
    Serial.println(client.getLastErrorMessage());
  }

  Serial.println("Wait 10s");
  delay(10000);

}

void deepSleep()
{
    esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR);                          //set deep sleep timer
    Serial.println("Setup ESP32 to sleep for every " + String(TIME_TO_SLEEP) + " Seconds"); //print a message
    Serial.println("Going to sleep now");                                                   //print a message
    esp_deep_sleep_start();                                                                 //put esp in deepsleep
}

//***************OPTIONAL***************OPTIONAL***************OPTIONAL***************OPTIONAL***************OPTIONAL***************

//IF YOU WANT TO SEND YOUR DATA TO THE VCELSTVA.CZU PROJECT (MORE ON THIS ON WIKIFACTORY) OF THE CZECH AGRICULTURAL UNIVERSITY,
//UNCOMMENT THE FUNCTION BELOW 

void httpPostVcelstva()
{
    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status
        HTTPClient http;
        Serial.print("HTTPPOST to VCELSTVA.CZU: ");                        //print a message
        Serial.println("https://vcelstva.czu.cz/callback/generic");        //print a destination of the HTTPpost request
        http.begin("https://vcelstva.czu.cz/callback/generic");            //Specify destination for HTTP request
        http.addHeader("Content-Type", "application/json", "Authorization, Basic <prusatoken>");
        int httpResponseCode = http.POST("{\"device\": \"prusahivescale\", \"time\": \"" + String(isoTime) + "\", \"weight\": " + String(weightRaw) + ", \"inner_temp_1\": " + String(tempOutside1) + ", \"outer_temp\": " + String(tempInside) + " }");

                                                //Send the actual POST request

        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {
            Serial.print("Error on sending POST: "); //print a message
            Serial.println(httpResponseCode);        //print the responsecode
        }
        http.end(); //Free resources
    }
    else
    {
        Serial.println("Error in WiFi connection"); //print a message
    }
}



//*************************************************************************************************
void setup() //this code runs once at the beginning
{
    Serial.begin(115200);  // initialize serial communication
}

//*************************************************************************************************

void loop()
{
    readBattery();
    readTemperatures();
    readWeight();
    wifiConnect();
    httpPost(beepAdress, beepKey, "bv=", battery);
    httpPost(beepAdress, beepKey, "w=", weightRaw);
    httpPost(beepAdress, beepKey, "t_i=", tempOutside1);
    httpPost(beepAdress, beepKey, "t=", tempInside);
    httpPost(beepAdress, beepKey, "h=", HumidityOut);
    httpPost(beepAdress, beepKey, "p=", PressureOut);    
    //readTime();
    //Serial.println(String(isoTime));
    //httpPostVcelstva();
    deepSleep();
}

//    ******************** Licenses ******************
//    Arduino Libraries are licensed under: LGPL and library source may be obtained:
//    http://arduino.cc/en/main/software
//    The Datalogger program utilized version 1.0.1 of the Arduino environment.
//    The source code for the Arduino environment is covered by the GPL. Please
//    reference the above link for free access to the Arduino environment.
//    ***********************************************
//    (c) Copyright and Right-To-Use for the main datalogger program:
//    All commercial rights are reserved - no exceptions. Rights holder:
//    M. Ray Burnette, Lawrenceville, Georgia, 30044-4522
//    Released under GNU General Pulic License, version 3 non-commercial use only.
//    http://opensource.org/licenses/GPL-3.0
//    ***********************************************