// PrusaHive V0.1 by Leoš Hort
// Open Source release: http://opensource.org/licenses/GPL-3.0
// Review license in entirety and note particularly sections 15 & 16.

#include <Arduino.h>
#include <HX711.h>
#include <soc/rtc.h>    //cpu slowdown
#include <WiFi.h>       //wifi library
#include <HTTPClient.h> //server communication library
#include <ezTime.h>     //ISO8601 timestamp library
#include <OneWire.h>
#include <DallasTemperature.h>

HX711 loadcell;
const char *ssid = "Prusa Research Guest"; //wifi name
const char *password = "prusaguest";       //wifi password
const int LOADCELL_DOUT_PIN = 0;           //com pin
const int LOADCELL_SCK_PIN = 4;            //clock pin
const long LOADCELL_DIVIDER = 32700.f;     //scale calibration
float weight = 1.1;                        // weight variable
float temp1 = 1.1;                         // temperature variable
float temp2 = 1.1;                         // temperature variable
int battery = 5000;                        // battery level variable
int NumConnect = 0;                        //counter of connectons to the wifi network

#define uS_TO_S_FACTOR 1000000ULL // Conversion factor for micro seconds to seconds
#define TIME_TO_SLEEP 1500        // Time ESP32 will go to sleep (in seconds)
#define ONE_WIRE_BUS 17           // Data wire is plugged into port 2 on the Arduino

// Setup a oneWire instance to communicate with any OneWire devices (not just Maxim/Dallas temperature ICs)
OneWire oneWire(ONE_WIRE_BUS);

// Pass our oneWire reference to Dallas Temperature.
DallasTemperature sensors(&oneWire);

void setup() //this code runs once at the beginning
{
    pinMode(5, OUTPUT);             //transistor pin
    pinMode(32, INPUT);             // pin for checking battery level
    battery = analogRead(32) + 750; // read the battery level roughly in milivolt
    digitalWrite(5, HIGH);          // turn on the stepup converter
    Serial.begin(115200);           //initialize serial communication
    Serial.println("PrusaHive Wakes up!"); // wakeup message
    loadcell.begin(LOADCELL_DOUT_PIN, LOADCELL_SCK_PIN); //inicialize scale
    loadcell.set_scale(LOADCELL_DIVIDER);                //calibrating scale

    sensors.begin();           //startup the temp sensors
    sensors.setResolution(10); //set the resolution of the sensors
    NumConnect = 0; //reset the wificonnection counter
    delay(4000); //Delay needed before calling the WiFi.begin

    WiFi.begin(ssid, password);     // accessing the wifi network

    while (WiFi.status() != WL_CONNECTED) //Check for the connection
    { 
        delay(1000);
        Serial.println("Connecting to WiFi..");
        NumConnect = NumConnect + 1;
        Serial.println(NumConnect);
        if (NumConnect > 5)
        {
            Serial.println("Cannot connect to the WiFi network");
            Serial.println("aborting ");
            esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR); //set deep sleep timer
            Serial.println("Lets try again in " + String(TIME_TO_SLEEP) + " Seconds");
            Serial.println("Going to sleep now");
            esp_deep_sleep_start(); //put esp in deepsleep
        }
    }

    Serial.println("Connected to the WiFi network");
}

void loop()
{ //this code loops endlessly

    if (loadcell.wait_ready_timeout(1000))
    {                                            //wait time for searching for AD module, if it initializes follow
        weight = loadcell.get_units(10) + 12.34; //calculating average from ten readings
        Serial.print("Weight: ");                //print text "weight"
        Serial.println(weight);                  // print the "weight variable
    }
    else
    { //if module cannot reach the AD module print following
        Serial.println("HX711 not found.");
        weight = 54.321;
    }

    // call sensors.requestTemperatures() to issue a global temperature
    // request to all devices on the bus
    Serial.print("Requesting temperatures...");
    sensors.requestTemperatures(); // Send the command to get temperatures
    Serial.println("DONE");
    // After we got the temperatures, we can print them here.
    // We use the function ByIndex, and as an example get the temperature from the first sensor only.
    Serial.print("Temperature for the device 1 (index 0) is: ");
    temp1 = sensors.getTempCByIndex(0);
    Serial.println("temp1");
    Serial.println(temp1);
    Serial.print("Temperature for the device 2 (index 1) is: ");
    temp2 = sensors.getTempCByIndex(1);
    Serial.println("temp2");
    Serial.println(temp2);

    loadcell.power_down(); // put the ADC in sleep mode
    digitalWrite(5, LOW);  // turn off the stepup converter

    Serial.print("battery: "); //print text "battery"
    Serial.println(battery);   // print the "battery variable

    //HTTPS SEND BATTERY DATA
    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status

        HTTPClient http;

        http.begin(String("https://api.beep.nl/api/sensors?key=340B87BF713C&bv=") + String(battery)); //Specify destination for HTTP request
        int httpResponseCode = http.POST("bv=5");                                                     //Send the actual POST request

        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {

            Serial.print("Error on sending POST: ");
            Serial.println(httpResponseCode);
        }

        http.end(); //Free resources
    }
    else
    {

        Serial.println("Error in WiFi connection");
    }

    //HTTPS SEND WEIGHT DATA
    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status

        HTTPClient http;

        http.begin(String("https://api.beep.nl/api/sensors?key=340B87BF713C&w=") + String(weight)); //Specify destination for HTTP request
        int httpResponseCode = http.POST("w=5");                                                    //Send the actual POST request

        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {

            Serial.print("Error on sending POST: ");
            Serial.println(httpResponseCode);
        }

        http.end(); //Free resources
    }
    else
    {

        Serial.println("Error in WiFi connection");
    }

    //HTTPS SEND TEMP1 DATA

    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status

        HTTPClient http;

        http.begin(String("https://api.beep.nl/api/sensors?key=340B87BF713C&t_i=") + String(temp1)); //Specify destination for HTTP request
        int httpResponseCode = http.POST("w=5");                                                     //Send the actual POST request

        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {

            Serial.print("Error on sending POST: ");
            Serial.println(httpResponseCode);
        }

        http.end(); //Free resources
    }
    else
    {

        Serial.println("Error in WiFi connection");
    }

    //HTTPS SEND TEMP2 DATA

    if (WiFi.status() == WL_CONNECTED)
    { //Check WiFi connection status

        HTTPClient http;

        http.begin(String("https://api.beep.nl/api/sensors?key=340B87BF713C&t=") + String(temp2)); //Specify destination for HTTP request
        int httpResponseCode = http.POST("w=5");                                                   //Send the actual POST request

        if (httpResponseCode > 0)
        {
            String response = http.getString(); //Get the response to the request
            Serial.println(httpResponseCode);   //Print return code
            Serial.println(response);           //Print request answer
        }
        else
        {

            Serial.print("Error on sending POST: ");
            Serial.println(httpResponseCode);
        }

        http.end(); //Free resources
    }
    else
    {

        Serial.println("Error in WiFi connection");
    }

    waitForSync();                                       //sync for the timestamp
    Serial.println("IS8601:      " + dateTime(ISO8601)); //print the timestamp in ISO8601 format

    esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR); //set deep sleep timer
    Serial.println("Setup ESP32 to sleep for every " + String(TIME_TO_SLEEP) + " Seconds");
    Serial.println("Going to sleep now");
    esp_deep_sleep_start(); //put esp in deepsleep
}

//    ******************** Licenses ******************
//    Arduino Libraries are licensed under: LGPL and library source may be obtained:
//    http://arduino.cc/en/main/software
//    The Datalogger program utilized version 1.0.1 of the Arduino environment.
//    The source code for the Arduino environment is covered by the GPL. Please
//    reference the above link for free access to the Arduino environment.
//    ***********************************************
//    (c) Copyright and Right-To-Use for the main datalogger program:
//    All commercial rights are reserved - no exceptions. Rights holder:
//    M. Ray Burnette, Lawrenceville, Georgia, 30044-4522
//    Released under GNU General Pulic License, version 3 non-commercial use only.
//    http://opensource.org/licenses/GPL-3.0
//    ***********************************************